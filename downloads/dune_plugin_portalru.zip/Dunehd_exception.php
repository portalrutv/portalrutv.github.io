<?php

class DunehdException extends Exception
{
    public $description;
    public function __construct($message, $code, $previous = null, $description = null)
    {
        $this->description = $description;

        parent::__construct($message, $code, $previous);
    }
};

?>
