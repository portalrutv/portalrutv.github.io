<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/tv/default_channel.php';

///////////////////////////////////////////////////////////////////////////
class DunehdChannel extends DefaultChannel

{
    private $number;
    private $past_epg_days;
    private $future_epg_days;
    private $buf_time;
    private $protect;
    private $arch;
    private $is_video;
	private $order;
	private $archive_delay;

    ///////////////////////////////////////////////////////////////////////

    public function __construct(
        $id, $title, $icon_url, $streaming_url, $number, $order, $past_epg_days, $future_epg_days, $buf_time,$protect,$arch,$is_video,$archive_delay)
    {
        hd_print($streaming_url);
        parent::__construct($id, $title, $icon_url, $streaming_url);

        $this->number = $number;
		$this->order = $order;
        $this->past_epg_days = $past_epg_days;
        $this->future_epg_days = $future_epg_days;
        $this->buf_time = $buf_time;
        $this->protect = $protect;
        $this->arch = $arch;
        $this->is_video = $is_video;
		$this->archive_delay = $archive_delay;
    }

    ///////////////////////////////////////////////////////////////////////

    public function get_buffering_ms()
    { return $this->buf_time; }
    
    public function get_number()
    { return $this->number; }
	
    public function set_number($number)
    { $this->number = $number; }

    public function get_order()
    { return $this->order; }

    public function get_past_epg_days()
    { return $this->past_epg_days; }

    public function get_future_epg_days()
    { return $this->future_epg_days; }

    public function is_protected()
    { return $this->protect; }

    public function has_archive()
    { return $this->arch; }

    public function is_video()
    { return $this->is_video; }
	
    public function get_archive_delay_sec()
    { return $this->archive_delay ; /*15 * 60; */}
}

///////////////////////////////////////////////////////////////////////////
?>
